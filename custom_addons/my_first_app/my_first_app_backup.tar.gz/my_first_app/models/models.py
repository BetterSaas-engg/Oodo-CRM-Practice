from odoo import models, fields, api
from datetime import date
from dateutil.relativedelta import relativedelta

class EeliElevator(models.Model):
    _name = 'eel.elevator'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Elevator Asset Registry'

    name = fields.Char(string='Device ID', required=True, tracking=True)
    owner_id = fields.Many2one('res.partner', string='Name of Customer', tracking=True)
    contract_start = fields.Date(string='Start Date')
    contract_end = fields.Date(string='End Date')
    visits_count = fields.Integer(string='Number of visits', default=4)
    service_route = fields.Char(string='Service Route')
    pmi_task_ids = fields.One2many('eel.pmi.task', 'elevator_id', string='PMI Tasks')
    
    # Days to Renewal calculation
    days_to_renewal = fields.Integer(string='Days to Renewal', compute='_compute_renewal_days')

    @api.depends('contract_end')
    def _compute_renewal_days(self):
        today = date.today()
        for rec in self:
            rec.days_to_renewal = (rec.contract_end - today).days if rec.contract_end else 0

    def action_generate_pmis(self):
        self.ensure_one()
        if not self.contract_start or self.visits_count <= 0:
            return
        interval = 12 // self.visits_count
        for i in range(self.visits_count):
            planned_date = self.contract_start + relativedelta(months=i*interval)
            self.env['eel.pmi.task'].create({
                'elevator_id': self.id,
                'scheduled_date': planned_date,
                'state': 'planned',
            })

class EeliPMITask(models.Model):
    _name = 'eel.pmi.task'
    _description = 'PMI Maintenance Task'
    _order = 'scheduled_date asc'

    elevator_id = fields.Many2one('eel.elevator', string='Elevator', ondelete='cascade')
    scheduled_date = fields.Date(string='Projected Date')
    actual_date = fields.Date(string='Actual Date')
    mechanic_id = fields.Many2one('res.users', string='Mechanic Assigned')
    state = fields.Selection([
        ('planned', 'Planned'),
        ('pending', 'Pending'),
        ('completed', 'Completed'),
        ('delayed', 'Delayed')
    ], default='planned', string='Status', compute='_compute_status', store=True, readonly=False)
    notes = fields.Text(string='Notes')

    @api.depends('scheduled_date', 'actual_date')
    def _compute_status(self):
        today = date.today()
        for rec in self:
            if rec.actual_date:
                rec.state = 'completed'
            elif rec.scheduled_date and rec.scheduled_date < today:
                rec.state = 'delayed'
            elif not rec.state:
                rec.state = 'planned'
