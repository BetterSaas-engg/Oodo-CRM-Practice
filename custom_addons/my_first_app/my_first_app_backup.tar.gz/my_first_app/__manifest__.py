{
    'name': 'EEL Operations',
    'version': '1.0',
    'category': 'Operations',
    'depends': ['base', 'mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
    ],
    'installable': True,
    'application': True,
}
